package com.apress.gerber.helloworld;

import android.graphics.drawable.shapes.RectShape;

import java.util.ArrayList;
import java.util.List;

public class Sandbox extends RectShape {
    private List<String> mGreetings = new ArrayList<String>();
    public static final String HELLO = "Hello Sandbox";

    //###########################################
    // CONSTRUCTORS
    //###########################################
    public Sandbox() {
    }

    public List<String> getGreetings() {
        return mGreetings;
    }

    public void setGreetings(List<String> greetings) {
        mGreetings = greetings;
    }

    @Override
    public boolean hasAlpha() {
        return true;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String greeting : mGreetings) {
            stringBuilder.append(greeting + " ");
        }
        return stringBuilder.toString().trim();
    }

    public boolean add(String object) {
        System.out.println("SandboQx.add");
        return mGreetings.add(object);
    }
}

